package com.anudip.ripository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.anudip.entity.Teacher;

public interface TeacherRiposirory extends JpaRepository<Teacher, Integer>{

	

}
