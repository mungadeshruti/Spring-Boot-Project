package com.anudip.exception;

public class BatchesNotFoundException extends RuntimeException {

	public  BatchesNotFoundException(String message)
	{
		super(message);
	}
}
