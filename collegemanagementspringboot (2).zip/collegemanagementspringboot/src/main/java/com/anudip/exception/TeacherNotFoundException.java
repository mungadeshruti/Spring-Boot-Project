package com.anudip.exception;

public class TeacherNotFoundException extends RuntimeException{

	public TeacherNotFoundException(String message)
	{
		super(message);
	}
}
