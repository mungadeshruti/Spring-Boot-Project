package com.anudip.exception;

public class CoursesNotFoundException extends RuntimeException{
	
	public  CoursesNotFoundException(String message)
	{
		super(message);
	}

}
